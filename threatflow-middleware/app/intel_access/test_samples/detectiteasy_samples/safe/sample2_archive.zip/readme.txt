This is a test ZIP archive

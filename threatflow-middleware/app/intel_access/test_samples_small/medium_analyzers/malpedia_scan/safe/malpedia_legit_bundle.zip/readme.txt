Legitimate bundle for Malpedia_Scan testing only.
